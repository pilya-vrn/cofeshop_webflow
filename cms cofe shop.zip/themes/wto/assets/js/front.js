$('form:not([action])').attr('action', '/');
$('form [data-name]').each(function(){ $(this).attr('name', $(this).attr('data-name')); });

jQuery(document).ready(function($){

  $('[href*=\"brandjs\"]').attr('style', 'display:none !important');

  $('a').not('.w--current,.active').each(function(){

    if(document.URL === $(this).attr('href')){
      $(this).addClass('w--current');
    }

  });

  $('form[action="/"]').on('submit', function(e){
    
    e.preventDefault();
    
    var cur_id = '#'+$(this).attr('id');

    if( !$(cur_id).find('[name=Page]')[0] ){
      $('<input type="hidden" name="Page" value="'+document.location.href+'">').prependTo(cur_id);
    }
    
    if( !$(cur_id).find('[name=Form]')[0] ){
      $('<input type="hidden" name="Form" value="'+$(cur_id).attr('data-name')+'">').prependTo(cur_id);
    }
    
    if( $(cur_id).attr('data-send') !== undefined && !$(cur_id).find('[name=sendTo]')[0] ) {
      $('<input type="hidden" name="sendTo" value="'+$(cur_id).attr('data-send')+'">').prependTo(cur_id);
    }
    
    $(this).request('onSendMail', { form: $(this)[0], files: true, success: function(data) {
      
      var redirect = $(cur_id).attr('data-redirect');
      if(redirect !== undefined && redirect !== '/-'){ 
        document.location.href = redirect;
        return(true); 
      }

      var hide = parseInt($(cur_id).attr('data-hide'));
      var delay = parseInt($(cur_id).attr('data-delay'));
      var replay_container = $(cur_id).siblings('.w-form-done');

      replay_container.show();
      
      if( hide ) $(cur_id).hide();
      if( delay ) replay_container.delay(delay).fadeOut();
      
      $(cur_id).trigger("reset");

    }});
  });

});
